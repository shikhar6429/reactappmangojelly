import { combineReducers } from 'redux'

import materials from './materials'

const rootReducer = combineReducers({
    materials
})

export default rootReducer