import React, { useState } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";

import MaterialForm from "../MaterialForm";

import { toggleCheckMaterial } from "../../actions/materials";

const Material = ({ material, toggleCheck }) => {
  const [editMaterials, setEditMaterials] = useState(false);

  const showForm = (fn) => {
    setEditMaterials(false);

    fn();
  };

  return (
    <>
      <tr>
        <td>
          <input
            type="checkbox"
            checked={material.checked}
            onChange={() => toggleCheck(material.id)}
          />
        </td>
        <td>{material.product}</td>
        <td>{material.type}</td>
        <td>{material.barcode}</td>
        <td>{material.delivery}</td>
        <td>{material.price}</td>
        <td>{material.unit}</td>
        <td>{material.quantity}</td>
        <td>{material.minimum}</td>
        <td>{material.maximum}</td>
        <td>
          <div className="buttons-set">
            <button
              onClick={() => showForm(() => setEditMaterials(!editMaterials))}
            >
              Edit
            </button>

            <button>Transfer</button>
          </div>
        </td>
      </tr>

      {editMaterials && (
        <tr>
          <td></td>
          <td colSpan={10}>
            <MaterialForm material={material} />
          </td>
        </tr>
      )}
    </>
  );
};

Material.propTypes = {
  material: PropTypes.object,
  toggleCheck: PropTypes.func
};

export default connect(null, (dispatch) => ({
  toggleCheck(id) {
    dispatch(toggleCheckMaterial(id));
  }
}))(Material);
